#ifndef FASTPLM_COMMON_H
#define FASTPLM_COMMON_H

// [[Rcpp::plugins(cpp11)]]

#include <algorithm>
#include <vector>

#include <RcppArmadillo.h>
using namespace Rcpp;
// [[Rcpp::depends(RcppArmadillo)]]

#endif
